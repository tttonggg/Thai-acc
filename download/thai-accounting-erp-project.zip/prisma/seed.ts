import { PrismaClient } from '@prisma/client'
import * as bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting seed...')

  // ============================================
  // Create Company
  // ============================================
  const company = await prisma.company.upsert({
    where: { id: 'company-1' },
    update: {},
    create: {
      id: 'company-1',
      name: 'บริษัท ไทย แอคเคานติ้ง จำกัด',
      nameEn: 'Thai Accounting Co., Ltd.',
      taxId: '0123456789012',
      branchCode: '00000',
      address: '123 ถนนสุขุมวิท แขวงคลองตัน',
      subDistrict: 'คลองตัน',
      district: 'วัฒนา',
      province: 'กรุงเทพมหานคร',
      postalCode: '10110',
      phone: '02-123-4567',
      fax: '02-123-4568',
      email: 'info@thaiaccounting.com',
      website: 'www.thaiaccounting.com',
      fiscalYearStart: 1,
    },
  })
  console.log('✅ Company created:', company.name)

  // ============================================
  // Create Users
  // ============================================
  const hashedPassword = await bcrypt.hash('admin123', 10)
  const hashedPasswordAcc = await bcrypt.hash('acc123', 10)
  const hashedPasswordUser = await bcrypt.hash('user123', 10)
  const hashedPasswordViewer = await bcrypt.hash('viewer123', 10)

  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@thaiaccounting.com' },
    update: {},
    create: {
      email: 'admin@thaiaccounting.com',
      name: 'ผู้ดูแลระบบ',
      password: hashedPassword,
      role: 'ADMIN',
      isActive: true,
    },
  })
  console.log('✅ Admin user created:', adminUser.email)

  const accountantUser = await prisma.user.upsert({
    where: { email: 'accountant@thaiaccounting.com' },
    update: {},
    create: {
      email: 'accountant@thaiaccounting.com',
      name: 'นักบัญชี ทดสอบ',
      password: hashedPasswordAcc,
      role: 'ACCOUNTANT',
      isActive: true,
    },
  })
  console.log('✅ Accountant user created:', accountantUser.email)

  const normalUser = await prisma.user.upsert({
    where: { email: 'user@thaiaccounting.com' },
    update: {},
    create: {
      email: 'user@thaiaccounting.com',
      name: 'ผู้ใช้ทั่วไป',
      password: hashedPasswordUser,
      role: 'USER',
      isActive: true,
    },
  })
  console.log('✅ Normal user created:', normalUser.email)

  const viewerUser = await prisma.user.upsert({
    where: { email: 'viewer@thaiaccounting.com' },
    update: {},
    create: {
      email: 'viewer@thaiaccounting.com',
      name: 'ผู้ดูเท่านั้น',
      password: hashedPasswordViewer,
      role: 'VIEWER',
      isActive: true,
    },
  })
  console.log('✅ Viewer user created:', viewerUser.email)

  // ============================================
  // Create Thai Chart of Accounts
  // ============================================
  const accounts = [
    // หมวดสินทรัพย์ (1xxx)
    { code: '1000', name: 'สินทรัพย์', type: 'ASSET', level: 1, isDetail: false },
    { code: '1100', name: 'สินทรัพย์หมุนเวียน', type: 'ASSET', level: 2, isDetail: false, parentId: '1000' },
    { code: '1110', name: 'เงินสดและเงินฝากธนาคาร', type: 'ASSET', level: 3, isDetail: false, parentId: '1100' },
    { code: '1111', name: 'เงินสด - ธนาคารกรุงเทพ', type: 'ASSET', level: 4, isDetail: true, parentId: '1110' },
    { code: '1112', name: 'เงินสด - ธนาคารกสิกรไทย', type: 'ASSET', level: 4, isDetail: true, parentId: '1110' },
    { code: '1113', name: 'เงินสด - เงินสดย่อย', type: 'ASSET', level: 4, isDetail: true, parentId: '1110' },
    { code: '1120', name: 'ลูกหนี้การค้า', type: 'ASSET', level: 3, isDetail: false, parentId: '1100' },
    { code: '1121', name: 'ลูกหนี้การค้า', type: 'ASSET', level: 4, isDetail: true, parentId: '1120' },
    { code: '1122', name: 'สำรองค่าเสื่อมราคาลูกหนี้', type: 'ASSET', level: 4, isDetail: true, parentId: '1120' },
    { code: '1130', name: 'ลูกหนี้อื่น', type: 'ASSET', level: 3, isDetail: false, parentId: '1100' },
    { code: '1131', name: 'เงินมัดจำ', type: 'ASSET', level: 4, isDetail: true, parentId: '1130' },
    { code: '1132', name: 'ภาษีมูลค่าเพิ่มถูกหัก ณ ที่จ่าย', type: 'ASSET', level: 4, isDetail: true, parentId: '1130' },
    { code: '1140', name: 'สินค้าคงเหลือ', type: 'ASSET', level: 3, isDetail: true, parentId: '1100' },
    { code: '1150', name: 'ค่าใช้จ่ายจ่ายล่วงหน้า', type: 'ASSET', level: 3, isDetail: true, parentId: '1100' },
    { code: '1200', name: 'สินทรัพย์ไม่หมุนเวียน', type: 'ASSET', level: 2, isDetail: false, parentId: '1000' },
    { code: '1210', name: 'ที่ดิน อาคารและอุปกรณ์', type: 'ASSET', level: 3, isDetail: false, parentId: '1200' },
    { code: '1211', name: 'ที่ดิน', type: 'ASSET', level: 4, isDetail: true, parentId: '1210' },
    { code: '1212', name: 'อาคาร', type: 'ASSET', level: 4, isDetail: true, parentId: '1210' },
    { code: '1213', name: 'ค่าเสื่อมราคาอาคารสะสม', type: 'ASSET', level: 4, isDetail: true, parentId: '1210' },
    { code: '1214', name: 'เครื่องจักรและอุปกรณ์', type: 'ASSET', level: 4, isDetail: true, parentId: '1210' },
    { code: '1215', name: 'ค่าเสื่อมราคาเครื่องจักรสะสม', type: 'ASSET', level: 4, isDetail: true, parentId: '1210' },
    { code: '1220', name: 'สินทรัพย์ไม่มีตัวตน', type: 'ASSET', level: 3, isDetail: true, parentId: '1200' },
    
    // หมวดหนี้สิน (2xxx)
    { code: '2000', name: 'หนี้สิน', type: 'LIABILITY', level: 1, isDetail: false },
    { code: '2100', name: 'หนี้สินหมุนเวียน', type: 'LIABILITY', level: 2, isDetail: false, parentId: '2000' },
    { code: '2110', name: 'เจ้าหนี้การค้า', type: 'LIABILITY', level: 3, isDetail: true, parentId: '2100' },
    { code: '2120', name: 'ตั๋วเงินจ่าย', type: 'LIABILITY', level: 3, isDetail: true, parentId: '2100' },
    { code: '2130', name: 'เจ้าหนี้อื่น', type: 'LIABILITY', level: 3, isDetail: false, parentId: '2100' },
    { code: '2131', name: 'ภาษีเงินได้หัก ณ ที่จ่าย', type: 'LIABILITY', level: 4, isDetail: true, parentId: '2130' },
    { code: '2132', name: 'ภาษีมูลค่าเพิ่มต้องชำระ', type: 'LIABILITY', level: 4, isDetail: true, parentId: '2130' },
    { code: '2133', name: 'ประกันสังคมต้องจ่าย', type: 'LIABILITY', level: 4, isDetail: true, parentId: '2130' },
    { code: '2140', name: 'เงินเดือนต้องจ่าย', type: 'LIABILITY', level: 3, isDetail: true, parentId: '2100' },
    { code: '2150', name: 'ภาษีเงินได้นิติบุคคลต้องชำระ', type: 'LIABILITY', level: 3, isDetail: true, parentId: '2100' },
    { code: '2200', name: 'หนี้สินไม่หมุนเวียน', type: 'LIABILITY', level: 2, isDetail: false, parentId: '2000' },
    { code: '2210', name: 'เงินกู้ยืมระยะยาว', type: 'LIABILITY', level: 3, isDetail: true, parentId: '2200' },
    
    // หมวดทุน (3xxx)
    { code: '3000', name: 'ส่วนของผู้ถือหุ้น', type: 'EQUITY', level: 1, isDetail: false },
    { code: '3100', name: 'ทุนจดทะเบียน', type: 'EQUITY', level: 2, isDetail: false, parentId: '3000' },
    { code: '3110', name: 'ทุนจดทะเบียนสามัญ', type: 'EQUITY', level: 3, isDetail: true, parentId: '3100' },
    { code: '3200', name: 'ทุนเกินมูลค่าหุ้น', type: 'EQUITY', level: 2, isDetail: true, parentId: '3000' },
    { code: '3300', name: 'กำไร(ขาดทุน)สะสม', type: 'EQUITY', level: 2, isDetail: true, parentId: '3000' },
    { code: '3400', name: 'งวดบัญชี', type: 'EQUITY', level: 2, isDetail: false, parentId: '3000' },
    { code: '3410', name: 'งวดบัญชีเจ้าหนี้', type: 'EQUITY', level: 3, isDetail: true, parentId: '3400' },
    
    // หมวดรายได้ (4xxx)
    { code: '4000', name: 'รายได้', type: 'REVENUE', level: 1, isDetail: false },
    { code: '4100', name: 'รายได้จากการขาย', type: 'REVENUE', level: 2, isDetail: false, parentId: '4000' },
    { code: '4110', name: 'รายได้จากการขายสินค้า', type: 'REVENUE', level: 3, isDetail: true, parentId: '4100' },
    { code: '4120', name: 'รายได้จากการให้บริการ', type: 'REVENUE', level: 3, isDetail: true, parentId: '4100' },
    { code: '4130', name: 'ส่วนลดให้แก่ลูกค้า', type: 'REVENUE', level: 3, isDetail: true, parentId: '4100' },
    { code: '4200', name: 'รายได้อื่น', type: 'REVENUE', level: 2, isDetail: false, parentId: '4000' },
    { code: '4210', name: 'ดอกเบี้ยรับ', type: 'REVENUE', level: 3, isDetail: true, parentId: '4200' },
    { code: '4220', name: 'รายได้ค่าเช่า', type: 'REVENUE', level: 3, isDetail: true, parentId: '4200' },
    { code: '4230', name: 'รายได้จากการจำหน่ายสินทรัพย์', type: 'REVENUE', level: 3, isDetail: true, parentId: '4200' },
    
    // หมวดค่าใช้จ่าย (5xxx)
    { code: '5000', name: 'ค่าใช้จ่าย', type: 'EXPENSE', level: 1, isDetail: false },
    { code: '5100', name: 'ต้นทุนขาย', type: 'EXPENSE', level: 2, isDetail: false, parentId: '5000' },
    { code: '5110', name: 'ต้นทุนสินค้าขาย', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5100' },
    { code: '5200', name: 'ค่าใช้จ่ายในการขาย', type: 'EXPENSE', level: 2, isDetail: false, parentId: '5000' },
    { code: '5210', name: 'ค่าโฆษณา', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5200' },
    { code: '5220', name: 'ค่าเดินทาง', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5200' },
    { code: '5230', name: 'ค่านายหน้า', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5200' },
    { code: '5300', name: 'ค่าใช้จ่ายในการบริหาร', type: 'EXPENSE', level: 2, isDetail: false, parentId: '5000' },
    { code: '5310', name: 'เงินเดือนและค่าจ้าง', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5320', name: 'ค่าเช่าอาคาร', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5330', name: 'ค่าน้ำประปา', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5340', name: 'ค่าไฟฟ้า', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5350', name: 'ค่าโทรศัพท์และอินเทอร์เน็ต', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5360', name: 'ค่าซ่อมแซมและบำรุงรักษา', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5370', name: 'ค่าขนส่ง', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5380', name: 'ค่าใช้จ่ายเบ็ดเตล็ด', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5390', name: 'ค่าเสื่อมราคา', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5300' },
    { code: '5400', name: 'ค่าใช้จ่ายทางการเงิน', type: 'EXPENSE', level: 2, isDetail: false, parentId: '5000' },
    { code: '5410', name: 'ดอกเบี้ยจ่าย', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5400' },
    { code: '5420', name: 'ค่าธรรมเนียมธนาคาร', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5400' },
    { code: '5500', name: 'ภาษีและส่วนสมทบ', type: 'EXPENSE', level: 2, isDetail: false, parentId: '5000' },
    { code: '5510', name: 'ภาษีเงินได้นิติบุคคล', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5500' },
    { code: '5520', name: 'ภาษีธุรกิจเฉพาะ', type: 'EXPENSE', level: 3, isDetail: true, parentId: '5500' },
  ]

  // Create parent ID mapping
  const accountIdMap: Record<string, string> = {}

  // First pass - create all accounts
  for (const account of accounts) {
    const created = await prisma.chartOfAccount.upsert({
      where: { code: account.code },
      update: {
        name: account.name,
        type: account.type as any,
        level: account.level,
        isDetail: account.isDetail,
        isSystem: true,
      },
      create: {
        code: account.code,
        name: account.name,
        type: account.type as any,
        level: account.level,
        isDetail: account.isDetail,
        isSystem: true,
        isActive: true,
      },
    })
    accountIdMap[account.code] = created.id
  }

  // Second pass - update parent references
  for (const account of accounts) {
    if (account.parentId) {
      await prisma.chartOfAccount.update({
        where: { code: account.code },
        data: {
          parentId: accountIdMap[account.parentId],
        },
      })
    }
  }
  console.log('✅ Chart of Accounts created:', accounts.length, 'accounts')

  // ============================================
  // Create Document Numbers
  // ============================================
  const docNumbers = [
    { type: 'JOURNAL', prefix: 'JE', format: '{prefix}{yyyy}{mm}-{0000}' },
    { type: 'INVOICE', prefix: 'INV', format: '{prefix}{yyyy}{mm}-{0000}' },
    { type: 'RECEIPT', prefix: 'RC', format: '{prefix}{yyyy}{mm}-{0000}' },
    { type: 'PAYMENT', prefix: 'PY', format: '{prefix}{yyyy}{mm}-{0000}' },
    { type: 'CREDIT_NOTE', prefix: 'CN', format: '{prefix}{yyyy}{mm}-{0000}' },
    { type: 'DEBIT_NOTE', prefix: 'DN', format: '{prefix}{yyyy}{mm}-{0000}' },
    { type: 'PURCHASE', prefix: 'PO', format: '{prefix}{yyyy}{mm}-{0000}' },
    { type: 'WHT_CERT', prefix: 'WHT', format: '{prefix}{yyyy}{mm}-{0000}' },
  ]

  for (const doc of docNumbers) {
    await prisma.documentNumber.upsert({
      where: { type: doc.type },
      update: {},
      create: {
        type: doc.type,
        prefix: doc.prefix,
        format: doc.format,
        currentNo: 0,
        resetMonthly: true,
      },
    })
  }
  console.log('✅ Document Numbers created:', docNumbers.length, 'types')

  // ============================================
  // Create Sample Customers
  // ============================================
  const customers = [
    { code: 'C001', name: 'บริษัท เอบีซี จำกัด', taxId: '0105555123456', phone: '02-111-2222' },
    { code: 'C002', name: 'บริษัท เอ็กซ์วายแซด จำกัด', taxId: '0105555789012', phone: '02-333-4444' },
    { code: 'C003', name: 'ห้างหุ้นส่วนจำกัด ไทยเทรดดิ้ง', taxId: '0105555345678', phone: '02-555-6666' },
  ]

  for (const customer of customers) {
    await prisma.customer.upsert({
      where: { code: customer.code },
      update: {},
      create: {
        code: customer.code,
        name: customer.name,
        taxId: customer.taxId,
        phone: customer.phone,
        province: 'กรุงเทพมหานคร',
        creditDays: 30,
        creditLimit: 100000,
      },
    })
  }
  console.log('✅ Sample Customers created:', customers.length, 'customers')

  // ============================================
  // Create Sample Vendors
  // ============================================
  const vendors = [
    { code: 'V001', name: 'บริษัท ซัพพลายเออร์ จำกัด', taxId: '0105555111222', phone: '02-777-8888' },
    { code: 'V002', name: 'บริษัท โลจิสติกส์ไทย จำกัด', taxId: '0105555333444', phone: '02-999-0000' },
  ]

  for (const vendor of vendors) {
    await prisma.vendor.upsert({
      where: { code: vendor.code },
      update: {},
      create: {
        code: vendor.code,
        name: vendor.name,
        taxId: vendor.taxId,
        phone: vendor.phone,
        province: 'กรุงเทพมหานคร',
        creditDays: 30,
      },
    })
  }
  console.log('✅ Sample Vendors created:', vendors.length, 'vendors')

  // ============================================
  // Create Sample Products
  // ============================================
  const products = [
    { code: 'P001', name: 'สินค้าตัวอย่าง A', unit: 'ชิ้น', salePrice: 1000, costPrice: 700 },
    { code: 'P002', name: 'สินค้าตัวอย่าง B', unit: 'ชุด', salePrice: 2500, costPrice: 1800 },
    { code: 'S001', name: 'ค่าบริการให้คำปรึกษา', unit: 'ครั้ง', salePrice: 5000, costPrice: 0, type: 'SERVICE' },
    { code: 'S002', name: 'ค่าบริการซ่อมบำรุง', unit: 'ครั้ง', salePrice: 3000, costPrice: 0, type: 'SERVICE' },
  ]

  for (const product of products) {
    await prisma.product.upsert({
      where: { code: product.code },
      update: {},
      create: {
        code: product.code,
        name: product.name,
        unit: product.unit,
        salePrice: product.salePrice,
        costPrice: product.costPrice,
        type: (product.type === 'SERVICE' ? 'SERVICE' : 'PRODUCT') as any,
      },
    })
  }
  console.log('✅ Sample Products created:', products.length, 'products')

  console.log('🎉 Seed completed successfully!')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
