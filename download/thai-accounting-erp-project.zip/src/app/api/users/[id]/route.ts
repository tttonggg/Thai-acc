import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/db'
import { z } from 'zod'
import * as bcrypt from 'bcryptjs'

const userUpdateSchema = z.object({
  email: z.string().email('รูปแบบอีเมลไม่ถูกต้อง').optional(),
  name: z.string().min(1, 'ชื่อต้องไม่ว่าง').optional(),
  password: z.string().min(6, 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร').optional(),
  role: z.enum(['ADMIN', 'ACCOUNTANT', 'USER', 'VIEWER']).optional(),
  isActive: z.boolean().optional(),
})

// GET - Get single user
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const user = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
        updatedAt: true,
      },
    })
    
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'ไม่พบผู้ใช้นี้' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({ success: true, data: user })
  } catch (error: any) {
    console.error('Error fetching user:', error)
    return NextResponse.json(
      { success: false, error: 'เกิดข้อผิดพลาดในการดึงข้อมูล' },
      { status: 500 }
    )
  }
}

// PUT - Update user
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const validatedData = userUpdateSchema.parse(body)
    
    const existing = await prisma.user.findUnique({
      where: { id },
    })
    
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'ไม่พบผู้ใช้นี้' },
        { status: 404 }
      )
    }
    
    // Check email uniqueness if changing
    if (validatedData.email && validatedData.email !== existing.email) {
      const emailExists = await prisma.user.findUnique({
        where: { email: validatedData.email },
      })
      
      if (emailExists) {
        return NextResponse.json(
          { success: false, error: 'อีเมลนี้มีอยู่แล้วในระบบ' },
          { status: 400 }
        )
      }
    }
    
    // Hash password if provided
    let updateData: any = { ...validatedData }
    if (validatedData.password) {
      updateData.password = await bcrypt.hash(validatedData.password, 10)
    } else {
      delete updateData.password
    }
    
    const user = await prisma.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        isActive: true,
        updatedAt: true,
      },
    })
    
    return NextResponse.json({ success: true, data: user })
  } catch (error: any) {
    console.error('Error updating user:', error)
    if (error.name === 'ZodError') {
      return NextResponse.json(
        { success: false, error: 'ข้อมูลไม่ถูกต้อง', details: error.errors },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { success: false, error: error.message || 'เกิดข้อผิดพลาดในการอัปเดต' },
      { status: 500 }
    )
  }
}

// DELETE - Delete user
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const existing = await prisma.user.findUnique({
      where: { id },
    })
    
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'ไม่พบผู้ใช้นี้' },
        { status: 404 }
      )
    }
    
    // Prevent deleting the last admin
    if (existing.role === 'ADMIN') {
      const adminCount = await prisma.user.count({
        where: { role: 'ADMIN', isActive: true },
      })
      
      if (adminCount <= 1) {
        return NextResponse.json(
          { success: false, error: 'ไม่สามารถลบ Admin คนสุดท้ายได้' },
          { status: 400 }
        )
      }
    }
    
    await prisma.user.delete({
      where: { id },
    })
    
    return NextResponse.json({ success: true, message: 'ลบผู้ใช้สำเร็จ' })
  } catch (error: any) {
    console.error('Error deleting user:', error)
    return NextResponse.json(
      { success: false, error: error.message || 'เกิดข้อผิดพลาดในการลบ' },
      { status: 500 }
    )
  }
}
