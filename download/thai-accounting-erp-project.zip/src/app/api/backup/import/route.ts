import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || session.user?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized - Admin only' }, { status: 401 })
    }

    const backup = await request.json()

    if (!backup.data) {
      return NextResponse.json({ error: 'Invalid backup file format' }, { status: 400 })
    }

    // Use transaction to ensure data consistency
    await prisma.$transaction(async (tx) => {
      // Import accounts
      if (backup.data.accounts && Array.isArray(backup.data.accounts)) {
        for (const account of backup.data.accounts) {
          await tx.chartOfAccount.upsert({
            where: { id: account.id },
            update: account,
            create: account
          })
        }
      }

      // Import customers
      if (backup.data.customers && Array.isArray(backup.data.customers)) {
        for (const customer of backup.data.customers) {
          await tx.customer.upsert({
            where: { id: customer.id },
            update: customer,
            create: customer
          })
        }
      }

      // Import vendors
      if (backup.data.vendors && Array.isArray(backup.data.vendors)) {
        for (const vendor of backup.data.vendors) {
          await tx.vendor.upsert({
            where: { id: vendor.id },
            update: vendor,
            create: vendor
          })
        }
      }

      // Import company info
      if (backup.data.company) {
        const existingCompany = await tx.company.findFirst()
        if (existingCompany) {
          await tx.company.update({
            where: { id: existingCompany.id },
            data: backup.data.company
          })
        } else {
          await tx.company.create({
            data: backup.data.company
          })
        }
      }
    })

    return NextResponse.json({ 
      success: true,
      message: 'Data imported successfully',
      imported: {
        accounts: backup.data.accounts?.length || 0,
        customers: backup.data.customers?.length || 0,
        vendors: backup.data.vendors?.length || 0
      }
    })
  } catch (error) {
    console.error('Import error:', error)
    return NextResponse.json({ 
      error: 'Failed to import data' 
    }, { status: 500 })
  }
}
