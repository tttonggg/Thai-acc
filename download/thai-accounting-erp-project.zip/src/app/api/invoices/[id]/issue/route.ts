import { db } from "@/lib/db"
import { requireAuth, apiResponse, apiError, unauthorizedError, notFoundError } from "@/lib/api-utils"

// POST /api/invoices/[id]/issue - Issue invoice
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth()
    const { id } = await params
    
    if (user.role === "VIEWER") {
      return apiError("ไม่มีสิทธิ์ออกใบกำกับภาษี", 403)
    }
    
    const existing = await db.invoice.findUnique({
      where: { id },
      include: {
        lines: true,
        customer: true
      }
    })
    
    if (!existing) {
      return notFoundError("ไม่พบใบกำกับภาษี")
    }
    
    if (existing.status !== "DRAFT") {
      return apiError("ใบกำกับภาษีนี้ออกแล้ว")
    }
    
    if (existing.lines.length === 0) {
      return apiError("ใบกำกับภาษีต้องมีอย่างน้อย 1 รายการ")
    }
    
    // Update status to issued
    const invoice = await db.invoice.update({
      where: { id },
      data: { status: "ISSUED" }
    })
    
    // Create VAT record
    await db.vatRecord.create({
      data: {
        type: "OUTPUT",
        documentNo: existing.invoiceNo,
        documentDate: existing.invoiceDate,
        documentType: "INVOICE",
        referenceId: existing.id,
        customerId: existing.customerId,
        customerName: existing.customer.name,
        customerTaxId: existing.customer.taxId,
        description: existing.description || `ใบกำกับภาษี ${existing.invoiceNo}`,
        subtotal: existing.subtotal,
        vatRate: existing.vatRate,
        vatAmount: existing.vatAmount,
        totalAmount: existing.totalAmount,
        taxMonth: existing.invoiceDate.getMonth() + 1,
        taxYear: existing.invoiceDate.getFullYear(),
      }
    })
    
    return apiResponse({ message: "ออกใบกำกับภาษีสำเร็จ", invoice })
  } catch (error) {
    if (error instanceof Error && error.message.includes("ไม่ได้รับอนุญาต")) {
      return unauthorizedError()
    }
    console.error(error)
    return apiError("เกิดข้อผิดพลาดในการออกใบกำกับภาษี")
  }
}
