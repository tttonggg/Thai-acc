'use client'

import { useState } from 'react'
import { 
  FileText, 
  Download, 
  Printer,
  Calculator
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const pnd3Records = [
  { id: '1', date: '01/01/2567', docNo: 'WHT-001', employee: 'นายสมชาย ใจดี', income: 50000, rate: 3, tax: 1500 },
  { id: '2', date: '01/01/2567', docNo: 'WHT-002', employee: 'นางสมหญิง รักษ์ดี', income: 45000, rate: 3, tax: 1350 },
  { id: '3', date: '01/01/2567', docNo: 'WHT-003', employee: 'นายสมศักดิ์ มั่นคง', income: 55000, rate: 3, tax: 1650 },
]

const pnd53Records = [
  { id: '1', date: '01/01/2567', docNo: 'WHT-101', vendor: 'บริษัทบริการ A', income: 100000, rate: 3, tax: 3000, incomeType: 'ค่าบริการ' },
  { id: '2', date: '02/01/2567', docNo: 'WHT-102', vendor: 'บริษัทเช่า B', income: 50000, rate: 5, tax: 2500, incomeType: 'ค่าเช่า' },
  { id: '3', date: '03/01/2567', docNo: 'WHT-103', vendor: 'บริษัทรับเหมา C', income: 200000, rate: 3, tax: 6000, incomeType: 'ค่ารับเหมา' },
]

export function WhtReport() {
  const [selectedMonth, setSelectedMonth] = useState('6')
  const [selectedYear, setSelectedYear] = useState('2567')
  const [selectedType, setSelectedType] = useState('pnd53')

  const totalPnd3 = pnd3Records.reduce((sum, r) => sum + r.tax, 0)
  const totalPnd53 = pnd53Records.reduce((sum, r) => sum + r.tax, 0)

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">ภาษีหัก ณ ที่จ่าย</h1>
          <p className="text-gray-500 mt-1">รายงานภาษีเงินได้หัก ณ ที่จ่าย (ภงด.3, ภงด.53)</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">มกราคม</SelectItem>
              <SelectItem value="2">กุมภาพันธ์</SelectItem>
              <SelectItem value="3">มีนาคม</SelectItem>
              <SelectItem value="4">เมษายน</SelectItem>
              <SelectItem value="5">พฤษภาคม</SelectItem>
              <SelectItem value="6">มิถุนายน</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-[100px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2567">2567</SelectItem>
              <SelectItem value="2566">2566</SelectItem>
              <SelectItem value="2565">2565</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Printer className="h-4 w-4 mr-2" />
            พิมพ์
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Download className="h-4 w-4 mr-2" />
            ส่งออก
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">ภงด.3 (เงินเดือน/ค่าจ้าง)</p>
                <p className="text-2xl font-bold text-purple-600">฿{totalPnd3.toLocaleString()}</p>
                <p className="text-xs text-gray-400">{pnd3Records.length} รายการ</p>
              </div>
              <FileText className="h-10 w-10 text-purple-200" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-teal-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">ภงด.53 (ค่าบริการ/ค่าเช่า)</p>
                <p className="text-2xl font-bold text-teal-600">฿{totalPnd53.toLocaleString()}</p>
                <p className="text-xs text-gray-400">{pnd53Records.length} รายการ</p>
              </div>
              <FileText className="h-10 w-10 text-teal-200" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-red-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">รวมภาษีที่ต้องยื่น</p>
                <p className="text-2xl font-bold text-red-600">฿{(totalPnd3 + totalPnd53).toLocaleString()}</p>
                <p className="text-xs text-gray-400">{pnd3Records.length + pnd53Records.length} รายการ</p>
              </div>
              <Calculator className="h-10 w-10 text-red-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* WHT Tables */}
      <Tabs value={selectedType} onValueChange={setSelectedType}>
        <TabsList>
          <TabsTrigger value="pnd53">ภงด.53 - ค่าบริการ/ค่าเช่า</TabsTrigger>
          <TabsTrigger value="pnd3">ภงด.3 - เงินเดือน/ค่าจ้าง</TabsTrigger>
        </TabsList>
        
        <TabsContent value="pnd53">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">รายละเอียด ภงด.53</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>วันที่</TableHead>
                    <TableHead>เลขที่หนังสือรับรอง</TableHead>
                    <TableHead>ผู้ถูกหักภาษี</TableHead>
                    <TableHead>ประเภทเงินได้</TableHead>
                    <TableHead className="text-right">จำนวนเงินที่จ่าย</TableHead>
                    <TableHead className="text-center">อัตราภาษี</TableHead>
                    <TableHead className="text-right">ภาษีที่หัก</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pnd53Records.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.date}</TableCell>
                      <TableCell className="font-mono">{record.docNo}</TableCell>
                      <TableCell>{record.vendor}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{record.incomeType}</Badge>
                      </TableCell>
                      <TableCell className="text-right">฿{record.income.toLocaleString()}</TableCell>
                      <TableCell className="text-center">{record.rate}%</TableCell>
                      <TableCell className="text-right text-teal-600 font-semibold">฿{record.tax.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="bg-teal-50">
                    <TableCell colSpan={4} className="font-semibold">รวม</TableCell>
                    <TableCell className="text-right font-semibold">฿{pnd53Records.reduce((s, r) => s + r.income, 0).toLocaleString()}</TableCell>
                    <TableCell></TableCell>
                    <TableCell className="text-right font-semibold text-teal-600">฿{totalPnd53.toLocaleString()}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="pnd3">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">รายละเอียด ภงด.3</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>วันที่</TableHead>
                    <TableHead>เลขที่หนังสือรับรอง</TableHead>
                    <TableHead>พนักงาน</TableHead>
                    <TableHead className="text-right">เงินได้</TableHead>
                    <TableHead className="text-center">อัตราภาษี</TableHead>
                    <TableHead className="text-right">ภาษีที่หัก</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pnd3Records.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.date}</TableCell>
                      <TableCell className="font-mono">{record.docNo}</TableCell>
                      <TableCell>{record.employee}</TableCell>
                      <TableCell className="text-right">฿{record.income.toLocaleString()}</TableCell>
                      <TableCell className="text-center">{record.rate}%</TableCell>
                      <TableCell className="text-right text-purple-600 font-semibold">฿{record.tax.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="bg-purple-50">
                    <TableCell colSpan={3} className="font-semibold">รวม</TableCell>
                    <TableCell className="text-right font-semibold">฿{pnd3Records.reduce((s, r) => s + r.income, 0).toLocaleString()}</TableCell>
                    <TableCell></TableCell>
                    <TableCell className="text-right font-semibold text-purple-600">฿{totalPnd3.toLocaleString()}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
