'use client'

import { useState } from 'react'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2,
  Phone,
  Mail,
  MapPin
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'

interface Customer {
  id: string
  code: string
  name: string
  taxId: string
  phone: string
  email: string
  province: string
  creditLimit: number
  balance: number
  status: string
}

const sampleCustomers: Customer[] = [
  { id: '1', code: 'C001', name: 'บริษัท ABC จำกัด', taxId: '0105555000001', phone: '02-123-4567', email: 'abc@company.co.th', province: 'กรุงเทพมหานคร', creditLimit: 500000, balance: 120000, status: 'active' },
  { id: '2', code: 'C002', name: 'บริษัท XYZ จำกัด', taxId: '0105555000002', phone: '02-234-5678', email: 'xyz@company.co.th', province: 'ปทุมธานี', creditLimit: 300000, balance: 85000, status: 'active' },
  { id: '3', code: 'C003', name: 'ห้างหุ้นส่วน 123', taxId: '0205555000003', phone: '02-345-6789', email: '123@shop.co.th', province: 'นนทบุรี', creditLimit: 100000, balance: 25000, status: 'active' },
  { id: '4', code: 'C004', name: 'บริษัท DEF จำกัด', taxId: '0105555000004', phone: '02-456-7890', email: 'def@company.co.th', province: 'สมุทรปราการ', creditLimit: 200000, balance: 0, status: 'inactive' },
]

export function CustomerList() {
  const [searchTerm, setSearchTerm] = useState('')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  const filteredCustomers = sampleCustomers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.code.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const totalBalance = sampleCustomers.reduce((sum, c) => sum + c.balance, 0)
  const totalCreditLimit = sampleCustomers.reduce((sum, c) => sum + c.creditLimit, 0)

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">ลูกหนี้การค้า</h1>
          <p className="text-gray-500 mt-1">จัดการข้อมูลลูกค้าและลูกหนี้</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              เพิ่มลูกค้า
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>เพิ่มลูกค้าใหม่</DialogTitle>
              <DialogDescription>
                กรอกข้อมูลลูกค้าใหม่ตามแบบฟอร์มด้านล่าง
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">รหัสลูกค้า</Label>
                <Input className="col-span-3" placeholder="C005" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">ชื่อลูกค้า</Label>
                <Input className="col-span-3" placeholder="ชื่อบริษัท/ห้างหุ้นส่วน" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">เลขประจำตัวผู้เสียภาษี</Label>
                <Input className="col-span-3" placeholder="0105555000000" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">โทรศัพท์</Label>
                <Input className="col-span-3" placeholder="02-000-0000" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">อีเมล</Label>
                <Input className="col-span-3" placeholder="email@company.co.th" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">วงเงินเครดิต</Label>
                <Input className="col-span-3" type="number" placeholder="0" />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>ยกเลิก</Button>
              <Button onClick={() => setIsAddDialogOpen(false)}>บันทึก</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">จำนวนลูกค้า</p>
            <p className="text-2xl font-bold text-gray-800">{sampleCustomers.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">ลูกหนี้รวม</p>
            <p className="text-2xl font-bold text-blue-600">฿{totalBalance.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">วงเงินเครดิตรวม</p>
            <p className="text-2xl font-bold text-green-600">฿{totalCreditLimit.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">ใช้วงเงินแล้ว</p>
            <p className="text-2xl font-bold text-orange-600">{((totalBalance / totalCreditLimit) * 100).toFixed(1)}%</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="ค้นหาลูกค้า..." 
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Customer Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>รหัส</TableHead>
                <TableHead>ชื่อลูกค้า</TableHead>
                <TableHead>เลขประจำตัวผู้เสียภาษี</TableHead>
                <TableHead>ติดต่อ</TableHead>
                <TableHead className="text-right">วงเงินเครดิต</TableHead>
                <TableHead className="text-right">ยอดคงเหลือ</TableHead>
                <TableHead>สถานะ</TableHead>
                <TableHead className="text-center">จัดการ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.map((customer) => (
                <TableRow key={customer.id}>
                  <TableCell className="font-mono">{customer.code}</TableCell>
                  <TableCell className="font-medium">{customer.name}</TableCell>
                  <TableCell className="font-mono text-sm">{customer.taxId}</TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1 text-sm">
                        <Phone className="h-3 w-3 text-gray-400" />
                        {customer.phone}
                      </div>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Mail className="h-3 w-3" />
                        {customer.email}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">฿{customer.creditLimit.toLocaleString()}</TableCell>
                  <TableCell className="text-right font-semibold text-blue-600">฿{customer.balance.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge className={customer.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                      {customer.status === 'active' ? 'ใช้งาน' : 'ไม่ใช้งาน'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-center gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4 text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
