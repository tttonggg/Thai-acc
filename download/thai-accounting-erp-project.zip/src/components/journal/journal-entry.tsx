'use client'

import { useState } from 'react'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Save,
  Calculator
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'

interface JournalLine {
  id: string
  accountId: string
  accountName: string
  description: string
  debit: number
  credit: number
}

const sampleAccounts = [
  { id: '1111', name: 'เงินสด - ธนาคารกรุงเทพ' },
  { id: '1121', name: 'ลูกหนี้การค้า' },
  { id: '211', name: 'เจ้าหนี้การค้า' },
  { id: '411', name: 'รายได้จากการขาย' },
  { id: '511', name: 'ต้นทุนขาย' },
]

const initialJournalLines: JournalLine[] = [
  { id: '1', accountId: '', accountName: '', description: '', debit: 0, credit: 0 },
  { id: '2', accountId: '', accountName: '', description: '', debit: 0, credit: 0 },
]

export function JournalEntry() {
  const [journalDate, setJournalDate] = useState(new Date().toISOString().split('T')[0])
  const [description, setDescription] = useState('')
  const [reference, setReference] = useState('')
  const [lines, setLines] = useState<JournalLine[]>(initialJournalLines)

  const totalDebit = lines.reduce((sum, line) => sum + line.debit, 0)
  const totalCredit = lines.reduce((sum, line) => sum + line.credit, 0)
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01

  const addLine = () => {
    setLines([...lines, {
      id: Date.now().toString(),
      accountId: '',
      accountName: '',
      description: '',
      debit: 0,
      credit: 0
    }])
  }

  const removeLine = (id: string) => {
    if (lines.length > 2) {
      setLines(lines.filter(l => l.id !== id))
    }
  }

  const updateLine = (id: string, field: keyof JournalLine, value: string | number) => {
    setLines(lines.map(line => {
      if (line.id === id) {
        if (field === 'accountId') {
          const account = sampleAccounts.find(a => a.id === value)
          return { ...line, accountId: value as string, accountName: account?.name || '' }
        }
        return { ...line, [field]: value }
      }
      return line
    }))
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">บันทึกบัญชี</h1>
          <p className="text-gray-500 mt-1">บันทึกรายการบัญชีรายวัน</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calculator className="h-4 w-4 mr-2" />
            คำนวณ
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Save className="h-4 w-4 mr-2" />
            บันทึก
          </Button>
        </div>
      </div>

      {/* Journal Header */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">ข้อมูลรายการ</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="entryNo">เลขที่บันทึก</Label>
              <Input id="entryNo" value="JV-2024-0001" readOnly className="bg-gray-50" />
            </div>
            <div>
              <Label htmlFor="date">วันที่</Label>
              <Input 
                id="date" 
                type="date" 
                value={journalDate}
                onChange={(e) => setJournalDate(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="reference">เอกสารอ้างอิง</Label>
              <Input 
                id="reference" 
                placeholder="เช่น ใบกำกับภาษีเลขที่..."
                value={reference}
                onChange={(e) => setReference(e.target.value)}
              />
            </div>
            <div className="md:col-span-4">
              <Label htmlFor="description">รายการ</Label>
              <Textarea 
                id="description" 
                placeholder="อธิบายรายการบัญชี..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Journal Lines */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">รายการบัญชี</CardTitle>
          <Button variant="outline" size="sm" onClick={addLine}>
            <Plus className="h-4 w-4 mr-2" />
            เพิ่มรายการ
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[200px]">บัญชี</TableHead>
                <TableHead>รายการ</TableHead>
                <TableHead className="w-[150px] text-right">เดบิต</TableHead>
                <TableHead className="w-[150px] text-right">เครดิต</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lines.map((line) => (
                <TableRow key={line.id}>
                  <TableCell>
                    <Select 
                      value={line.accountId} 
                      onValueChange={(v) => updateLine(line.id, 'accountId', v)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="เลือกบัญชี" />
                      </SelectTrigger>
                      <SelectContent>
                        {sampleAccounts.map(account => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.id} - {account.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Input 
                      value={line.description}
                      onChange={(e) => updateLine(line.id, 'description', e.target.value)}
                      placeholder="รายการ..."
                    />
                  </TableCell>
                  <TableCell>
                    <Input 
                      type="number"
                      className="text-right"
                      value={line.debit || ''}
                      onChange={(e) => updateLine(line.id, 'debit', parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                    />
                  </TableCell>
                  <TableCell>
                    <Input 
                      type="number"
                      className="text-right"
                      value={line.credit || ''}
                      onChange={(e) => updateLine(line.id, 'credit', parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                    />
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => removeLine(line.id)}
                      disabled={lines.length <= 2}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {/* Totals */}
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-8">
                <div>
                  <span className="text-sm text-gray-500">รวมเดบิต: </span>
                  <span className="font-semibold text-blue-600">฿{totalDebit.toLocaleString('th-TH', { minimumFractionDigits: 2 })}</span>
                </div>
                <div>
                  <span className="text-sm text-gray-500">รวมเครดิต: </span>
                  <span className="font-semibold text-green-600">฿{totalCredit.toLocaleString('th-TH', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>
              <div>
                {isBalanced ? (
                  <Badge className="bg-green-100 text-green-800">
                    สมดุล ✓
                  </Badge>
                ) : (
                  <Badge className="bg-red-100 text-red-800">
                    ไม่สมดุล (ผลต่าง: ฿{Math.abs(totalDebit - totalCredit).toLocaleString('th-TH', { minimumFractionDigits: 2 })})
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Journal Entries */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">รายการล่าสุด</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>เลขที่</TableHead>
                <TableHead>วันที่</TableHead>
                <TableHead>รายการ</TableHead>
                <TableHead className="text-right">เดบิต</TableHead>
                <TableHead className="text-right">เครดิต</TableHead>
                <TableHead>สถานะ</TableHead>
                <TableHead className="text-center">จัดการ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-mono">JV-2024-0001</TableCell>
                <TableCell>01/01/2567</TableCell>
                <TableCell>รับชำระหนี้จากลูกค้า</TableCell>
                <TableCell className="text-right">฿50,000.00</TableCell>
                <TableCell className="text-right">฿50,000.00</TableCell>
                <TableCell>
                  <Badge className="bg-green-100 text-green-800">ลงบัญชีแล้ว</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex justify-center gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4 text-blue-600" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono">JV-2024-0002</TableCell>
                <TableCell>02/01/2567</TableCell>
                <TableCell>จ่ายเงินเดือนพนักงาน</TableCell>
                <TableCell className="text-right">฿120,000.00</TableCell>
                <TableCell className="text-right">฿120,000.00</TableCell>
                <TableCell>
                  <Badge className="bg-green-100 text-green-800">ลงบัญชีแล้ว</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex justify-center gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4 text-blue-600" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
