'use client'

import { useState } from 'react'
import { 
  FileText, 
  Download, 
  Printer,
  Calculator,
  TrendingUp,
  TrendingDown
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from 'recharts'

const monthlyVatData = [
  { month: 'ม.ค.', vatOutput: 31500, vatInput: 22400, net: 9100 },
  { month: 'ก.พ.', vatOutput: 36400, vatInput: 26600, net: 9800 },
  { month: 'มี.ค.', vatOutput: 33600, vatInput: 24500, net: 9100 },
  { month: 'เม.ย.', vatOutput: 42700, vatInput: 29400, net: 13300 },
  { month: 'พ.ค.', vatOutput: 38500, vatInput: 27300, net: 11200 },
  { month: 'มิ.ย.', vatOutput: 47600, vatInput: 31500, net: 16100 },
]

const vatOutputRecords = [
  { id: '1', date: '01/01/2567', docNo: 'INV-2024-0001', customer: 'บริษัท ABC จำกัด', amount: 50000, vat: 3500 },
  { id: '2', date: '02/01/2567', docNo: 'INV-2024-0002', customer: 'บริษัท XYZ จำกัด', amount: 100000, vat: 7000 },
  { id: '3', date: '03/01/2567', docNo: 'INV-2024-0003', customer: 'ห้างหุ้นส่วน 123', amount: 25000, vat: 1750 },
]

const vatInputRecords = [
  { id: '1', date: '01/01/2567', docNo: 'TAX-001', vendor: 'บริษัทผู้ผลิต A', amount: 320000, vat: 22400 },
  { id: '2', date: '02/01/2567', docNo: 'TAX-002', vendor: 'บริษัทค้าส่ง B', amount: 380000, vat: 26600 },
  { id: '3', date: '03/01/2567', docNo: 'TAX-003', vendor: 'บริษัทบริการ C', amount: 350000, vat: 24500 },
]

export function VatReport() {
  const [selectedMonth, setSelectedMonth] = useState('6')
  const [selectedYear, setSelectedYear] = useState('2567')

  const totalVatOutput = vatOutputRecords.reduce((sum, r) => sum + r.vat, 0)
  const totalVatInput = vatInputRecords.reduce((sum, r) => sum + r.vat, 0)
  const netVat = totalVatOutput - totalVatInput

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">ภาษีมูลค่าเพิ่ม (VAT)</h1>
          <p className="text-gray-500 mt-1">รายงานภาษีขายและภาษีซื้อ</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">มกราคม</SelectItem>
              <SelectItem value="2">กุมภาพันธ์</SelectItem>
              <SelectItem value="3">มีนาคม</SelectItem>
              <SelectItem value="4">เมษายน</SelectItem>
              <SelectItem value="5">พฤษภาคม</SelectItem>
              <SelectItem value="6">มิถุนายน</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-[100px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2567">2567</SelectItem>
              <SelectItem value="2566">2566</SelectItem>
              <SelectItem value="2565">2565</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Printer className="h-4 w-4 mr-2" />
            พิมพ์
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Download className="h-4 w-4 mr-2" />
            ส่งออก PP30
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">ภาษีขาย (Output VAT)</p>
                <p className="text-2xl font-bold text-blue-600">฿{totalVatOutput.toLocaleString()}</p>
              </div>
              <TrendingUp className="h-10 w-10 text-blue-200" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">ภาษีซื้อ (Input VAT)</p>
                <p className="text-2xl font-bold text-orange-600">฿{totalVatInput.toLocaleString()}</p>
              </div>
              <TrendingDown className="h-10 w-10 text-orange-200" />
            </div>
          </CardContent>
        </Card>
        <Card className={`border-l-4 ${netVat >= 0 ? 'border-l-red-500' : 'border-l-green-500'}`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">ภาษีที่ต้องชำระ/รับคืน</p>
                <p className={`text-2xl font-bold ${netVat >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                  ฿{Math.abs(netVat).toLocaleString()}
                </p>
                <p className="text-xs text-gray-400">{netVat >= 0 ? 'ต้องชำระ' : 'รับคืน'}</p>
              </div>
              <Calculator className={`h-10 w-10 ${netVat >= 0 ? 'text-red-200' : 'text-green-200'}`} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* VAT Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">กราฟเปรียบเทียบภาษีขาย-ภาษีซื้อ</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyVatData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `${v/1000}K`} />
              <Tooltip formatter={(value: number) => [`฿${value.toLocaleString()}`, '']} />
              <Legend />
              <Bar dataKey="vatOutput" name="ภาษีขาย" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="vatInput" name="ภาษีซื้อ" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* VAT Output Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">รายละเอียดภาษีขาย</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>วันที่</TableHead>
                <TableHead>เลขที่เอกสาร</TableHead>
                <TableHead>ลูกค้า</TableHead>
                <TableHead className="text-right">มูลค่าสินค้า/บริการ</TableHead>
                <TableHead className="text-right">ภาษีมูลค่าเพิ่ม</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vatOutputRecords.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>{record.date}</TableCell>
                  <TableCell className="font-mono">{record.docNo}</TableCell>
                  <TableCell>{record.customer}</TableCell>
                  <TableCell className="text-right">฿{record.amount.toLocaleString()}</TableCell>
                  <TableCell className="text-right text-blue-600 font-semibold">฿{record.vat.toLocaleString()}</TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-blue-50">
                <TableCell colSpan={3} className="font-semibold">รวม</TableCell>
                <TableCell className="text-right font-semibold">฿{vatOutputRecords.reduce((s, r) => s + r.amount, 0).toLocaleString()}</TableCell>
                <TableCell className="text-right font-semibold text-blue-600">฿{totalVatOutput.toLocaleString()}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* VAT Input Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">รายละเอียดภาษีซื้อ</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>วันที่</TableHead>
                <TableHead>เลขที่เอกสาร</TableHead>
                <TableHead>ผู้ขาย</TableHead>
                <TableHead className="text-right">มูลค่าสินค้า/บริการ</TableHead>
                <TableHead className="text-right">ภาษีมูลค่าเพิ่ม</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vatInputRecords.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>{record.date}</TableCell>
                  <TableCell className="font-mono">{record.docNo}</TableCell>
                  <TableCell>{record.vendor}</TableCell>
                  <TableCell className="text-right">฿{record.amount.toLocaleString()}</TableCell>
                  <TableCell className="text-right text-orange-600 font-semibold">฿{record.vat.toLocaleString()}</TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-orange-50">
                <TableCell colSpan={3} className="font-semibold">รวม</TableCell>
                <TableCell className="text-right font-semibold">฿{vatInputRecords.reduce((s, r) => s + r.amount, 0).toLocaleString()}</TableCell>
                <TableCell className="text-right font-semibold text-orange-600">฿{totalVatInput.toLocaleString()}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
