'use client'

import { useState } from 'react'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2,
  Phone,
  Mail,
  Building
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'

interface Vendor {
  id: string
  code: string
  name: string
  taxId: string
  phone: string
  email: string
  province: string
  creditDays: number
  balance: number
  status: string
}

const sampleVendors: Vendor[] = [
  { id: '1', code: 'V001', name: 'บริษัทผู้ผลิต A จำกัด', taxId: '0105556000001', phone: '02-111-1111', email: 'vendorA@factory.co.th', province: 'กรุงเทพมหานคร', creditDays: 30, balance: 180000, status: 'active' },
  { id: '2', code: 'V002', name: 'บริษัทค้าส่ง B จำกัด', taxId: '0105556000002', phone: '02-222-2222', email: 'vendorB@wholesale.co.th', province: 'ปทุมธานี', creditDays: 45, balance: 95000, status: 'active' },
  { id: '3', code: 'V003', name: 'บริษัทบริการ C จำกัด', taxId: '0105556000003', phone: '02-333-3333', email: 'vendorC@service.co.th', province: 'นนทบุรี', creditDays: 30, balance: 60000, status: 'active' },
  { id: '4', code: 'V004', name: 'บริษัทขนส่ง D จำกัด', taxId: '0105556000004', phone: '02-444-4444', email: 'vendorD@transport.co.th', province: 'สมุทรปราการ', creditDays: 15, balance: 30000, status: 'inactive' },
]

export function VendorList() {
  const [searchTerm, setSearchTerm] = useState('')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  const filteredVendors = sampleVendors.filter(vendor =>
    vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.code.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const totalBalance = sampleVendors.reduce((sum, v) => sum + v.balance, 0)

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">เจ้าหนี้การค้า</h1>
          <p className="text-gray-500 mt-1">จัดการข้อมูลผู้ขายและเจ้าหนี้</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              เพิ่มผู้ขาย
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>เพิ่มผู้ขายใหม่</DialogTitle>
              <DialogDescription>
                กรอกข้อมูลผู้ขายใหม่ตามแบบฟอร์มด้านล่าง
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">รหัสผู้ขาย</Label>
                <Input className="col-span-3" placeholder="V005" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">ชื่อผู้ขาย</Label>
                <Input className="col-span-3" placeholder="ชื่อบริษัท/ห้างหุ้นส่วน" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">เลขประจำตัวผู้เสียภาษี</Label>
                <Input className="col-span-3" placeholder="0105556000000" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">โทรศัพท์</Label>
                <Input className="col-span-3" placeholder="02-000-0000" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">เครดิต (วัน)</Label>
                <Input className="col-span-3" type="number" placeholder="30" />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>ยกเลิก</Button>
              <Button onClick={() => setIsAddDialogOpen(false)}>บันทึก</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">จำนวนผู้ขาย</p>
            <p className="text-2xl font-bold text-gray-800">{sampleVendors.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">เจ้าหนี้รวม</p>
            <p className="text-2xl font-bold text-orange-600">฿{totalBalance.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">ผู้ขายที่ใช้งาน</p>
            <p className="text-2xl font-bold text-green-600">{sampleVendors.filter(v => v.status === 'active').length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="ค้นหาผู้ขาย..." 
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Vendor Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>รหัส</TableHead>
                <TableHead>ชื่อผู้ขาย</TableHead>
                <TableHead>เลขประจำตัวผู้เสียภาษี</TableHead>
                <TableHead>ติดต่อ</TableHead>
                <TableHead className="text-center">เครดิต</TableHead>
                <TableHead className="text-right">ยอดคงเหลือ</TableHead>
                <TableHead>สถานะ</TableHead>
                <TableHead className="text-center">จัดการ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredVendors.map((vendor) => (
                <TableRow key={vendor.id}>
                  <TableCell className="font-mono">{vendor.code}</TableCell>
                  <TableCell className="font-medium">{vendor.name}</TableCell>
                  <TableCell className="font-mono text-sm">{vendor.taxId}</TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1 text-sm">
                        <Phone className="h-3 w-3 text-gray-400" />
                        {vendor.phone}
                      </div>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Mail className="h-3 w-3" />
                        {vendor.email}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">{vendor.creditDays} วัน</TableCell>
                  <TableCell className="text-right font-semibold text-orange-600">฿{vendor.balance.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge className={vendor.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                      {vendor.status === 'active' ? 'ใช้งาน' : 'ไม่ใช้งาน'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-center gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4 text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
