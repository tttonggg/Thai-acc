'use client'

import { useState } from 'react'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Eye,
  Download,
  Printer,
  FileText
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

interface Invoice {
  id: string
  invoiceNo: string
  date: string
  customerName: string
  subtotal: number
  vatAmount: number
  totalAmount: number
  status: string
  type: string
}

const sampleInvoices: Invoice[] = [
  { id: '1', invoiceNo: 'INV-2024-0001', date: '01/01/2567', customerName: 'บริษัท ABC จำกัด', subtotal: 50000, vatAmount: 3500, totalAmount: 53500, status: 'ISSUED', type: 'TAX_INVOICE' },
  { id: '2', invoiceNo: 'INV-2024-0002', date: '02/01/2567', customerName: 'บริษัท XYZ จำกัด', subtotal: 100000, vatAmount: 7000, totalAmount: 107000, status: 'PAID', type: 'TAX_INVOICE' },
  { id: '3', invoiceNo: 'INV-2024-0003', date: '03/01/2567', customerName: 'ห้างหุ้นส่วน 123', subtotal: 25000, vatAmount: 1750, totalAmount: 26750, status: 'PARTIAL', type: 'RECEIPT' },
  { id: '4', invoiceNo: 'CN-2024-0001', date: '04/01/2567', customerName: 'บริษัท ABC จำกัด', subtotal: 5000, vatAmount: 350, totalAmount: 5350, status: 'ISSUED', type: 'CREDIT_NOTE' },
  { id: '5', invoiceNo: 'INV-2024-0004', date: '05/01/2567', customerName: 'บริษัท DEF จำกัด', subtotal: 75000, vatAmount: 5250, totalAmount: 80250, status: 'DRAFT', type: 'TAX_INVOICE' },
]

const statusColors: Record<string, string> = {
  DRAFT: 'bg-gray-100 text-gray-800',
  ISSUED: 'bg-blue-100 text-blue-800',
  PARTIAL: 'bg-yellow-100 text-yellow-800',
  PAID: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
}

const statusLabels: Record<string, string> = {
  DRAFT: 'ร่าง',
  ISSUED: 'ออกแล้ว',
  PARTIAL: 'รับชำระบางส่วน',
  PAID: 'รับชำระเต็มจำนวน',
  CANCELLED: 'ยกเลิก',
}

const typeLabels: Record<string, string> = {
  TAX_INVOICE: 'ใบกำกับภาษี',
  RECEIPT: 'ใบเสร็จรับเงิน',
  DELIVERY_NOTE: 'ใบส่งของ',
  CREDIT_NOTE: 'ใบลดหนี้',
  DEBIT_NOTE: 'ใบเพิ่มหนี้',
}

export function InvoiceList() {
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  const filteredInvoices = sampleInvoices.filter(invoice => {
    const matchesSearch = invoice.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          invoice.invoiceNo.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === 'all' || invoice.status === filterStatus
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">ใบกำกับภาษี / เอกสารการขาย</h1>
          <p className="text-gray-500 mt-1">จัดการใบกำกับภาษี ใบเสร็จ และเอกสารที่เกี่ยวข้อง</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              สร้างเอกสารใหม่
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>สร้างเอกสารใหม่</DialogTitle>
              <DialogDescription>
                เลือกประเภทเอกสารที่ต้องการสร้าง
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <Button variant="outline" className="h-24 flex-col" onClick={() => setIsAddDialogOpen(false)}>
                <FileText className="h-8 w-8 mb-2 text-blue-600" />
                <span>ใบกำกับภาษี</span>
              </Button>
              <Button variant="outline" className="h-24 flex-col" onClick={() => setIsAddDialogOpen(false)}>
                <FileText className="h-8 w-8 mb-2 text-green-600" />
                <span>ใบเสร็จรับเงิน</span>
              </Button>
              <Button variant="outline" className="h-24 flex-col" onClick={() => setIsAddDialogOpen(false)}>
                <FileText className="h-8 w-8 mb-2 text-orange-600" />
                <span>ใบส่งของ</span>
              </Button>
              <Button variant="outline" className="h-24 flex-col" onClick={() => setIsAddDialogOpen(false)}>
                <FileText className="h-8 w-8 mb-2 text-red-600" />
                <span>ใบลดหนี้</span>
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">รอออกใบกำกับภาษี</p>
            <p className="text-2xl font-bold text-yellow-600">5</p>
            <p className="text-xs text-gray-400">รายการ</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">รอรับชำระ</p>
            <p className="text-2xl font-bold text-blue-600">12</p>
            <p className="text-xs text-gray-400">รายการ</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">รับชำระแล้ว (เดือนนี้)</p>
            <p className="text-2xl font-bold text-green-600">฿850,000</p>
            <p className="text-xs text-gray-400">45 รายการ</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-gray-500">ภาษีขายรวม</p>
            <p className="text-2xl font-bold text-purple-600">฿59,500</p>
            <p className="text-xs text-gray-400">เดือนนี้</p>
          </CardContent>
        </Card>
      </div>

      {/* Search & Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="ค้นหาตามชื่อลูกค้าหรือเลขที่เอกสาร..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="สถานะ" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ทั้งหมด</SelectItem>
                <SelectItem value="DRAFT">ร่าง</SelectItem>
                <SelectItem value="ISSUED">ออกแล้ว</SelectItem>
                <SelectItem value="PARTIAL">รับชำระบางส่วน</SelectItem>
                <SelectItem value="PAID">รับชำระเต็มจำนวน</SelectItem>
                <SelectItem value="CANCELLED">ยกเลิก</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Invoice Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>เลขที่</TableHead>
                <TableHead>วันที่</TableHead>
                <TableHead>ประเภท</TableHead>
                <TableHead>ลูกค้า</TableHead>
                <TableHead className="text-right">มูลค่าก่อน VAT</TableHead>
                <TableHead className="text-right">VAT</TableHead>
                <TableHead className="text-right">ยอดรวม</TableHead>
                <TableHead>สถานะ</TableHead>
                <TableHead className="text-center">จัดการ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell className="font-mono">{invoice.invoiceNo}</TableCell>
                  <TableCell>{invoice.date}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{typeLabels[invoice.type]}</Badge>
                  </TableCell>
                  <TableCell>{invoice.customerName}</TableCell>
                  <TableCell className="text-right">฿{invoice.subtotal.toLocaleString()}</TableCell>
                  <TableCell className="text-right">฿{invoice.vatAmount.toLocaleString()}</TableCell>
                  <TableCell className="text-right font-semibold">฿{invoice.totalAmount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge className={statusColors[invoice.status]}>
                      {statusLabels[invoice.status]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-center gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Eye className="h-4 w-4 text-gray-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4 text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Printer className="h-4 w-4 text-green-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Download className="h-4 w-4 text-purple-600" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
