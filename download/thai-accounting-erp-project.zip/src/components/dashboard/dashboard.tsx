'use client'

import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Truck, 
  Receipt,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend
} from 'recharts'

// Mock data for charts
const monthlyData = [
  { month: 'ม.ค.', revenue: 450000, expense: 320000 },
  { month: 'ก.พ.', revenue: 520000, expense: 380000 },
  { month: 'มี.ค.', revenue: 480000, expense: 350000 },
  { month: 'เม.ย.', revenue: 610000, expense: 420000 },
  { month: 'พ.ค.', revenue: 550000, expense: 390000 },
  { month: 'มิ.ย.', revenue: 680000, expense: 450000 },
]

const arAgingData = [
  { name: 'ไม่เกิน 30 วัน', value: 250000, color: '#22c55e' },
  { name: '31-60 วัน', value: 120000, color: '#3b82f6' },
  { name: '61-90 วัน', value: 80000, color: '#f59e0b' },
  { name: 'เกิน 90 วัน', value: 50000, color: '#ef4444' },
]

const apAgingData = [
  { name: 'ไม่เกิน 30 วัน', value: 180000, color: '#22c55e' },
  { name: '31-60 วัน', value: 90000, color: '#3b82f6' },
  { name: '61-90 วัน', value: 60000, color: '#f59e0b' },
  { name: 'เกิน 90 วัน', value: 30000, color: '#ef4444' },
]

const vatData = [
  { month: 'ม.ค.', vatOutput: 31500, vatInput: 22400 },
  { month: 'ก.พ.', vatOutput: 36400, vatInput: 26600 },
  { month: 'มี.ค.', vatOutput: 33600, vatInput: 24500 },
  { month: 'เม.ย.', vatOutput: 42700, vatInput: 29400 },
  { month: 'พ.ค.', vatOutput: 38500, vatInput: 27300 },
  { month: 'มิ.ย.', vatOutput: 47600, vatInput: 31500 },
]

// Summary Card Component
interface SummaryCardProps {
  title: string
  value: string
  change: number
  changeLabel: string
  icon: React.ReactNode
  iconBg: string
}

function SummaryCard({ title, value, change, changeLabel, icon, iconBg }: SummaryCardProps) {
  const isPositive = change >= 0
  
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500 mb-1">{title}</p>
            <p className="text-2xl font-bold text-gray-800">{value}</p>
            <div className={`flex items-center gap-1 mt-2 ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {isPositive ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
              <span className="text-sm font-medium">{Math.abs(change)}%</span>
              <span className="text-xs text-gray-400">{changeLabel}</span>
            </div>
          </div>
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${iconBg}`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-800">แดชบอร์ด</h1>
        <p className="text-gray-500 mt-1">ภาพรวมสถานะทางการเงินและบัญชี</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryCard
          title="รายได้รวม (เดือนนี้)"
          value="฿680,000"
          change={12.5}
          changeLabel="จากเดือนก่อน"
          icon={<TrendingUp className="h-6 w-6 text-white" />}
          iconBg="bg-green-500"
        />
        <SummaryCard
          title="ค่าใช้จ่ายรวม (เดือนนี้)"
          value="฿450,000"
          change={8.2}
          changeLabel="จากเดือนก่อน"
          icon={<TrendingDown className="h-6 w-6 text-white" />}
          iconBg="bg-red-500"
        />
        <SummaryCard
          title="ลูกหนี้การค้า"
          value="฿500,000"
          change={-5.3}
          changeLabel="จากเดือนก่อน"
          icon={<Users className="h-6 w-6 text-white" />}
          iconBg="bg-blue-500"
        />
        <SummaryCard
          title="เจ้าหนี้การค้า"
          value="฿360,000"
          change={-2.1}
          changeLabel="จากเดือนก่อน"
          icon={<Truck className="h-6 w-6 text-white" />}
          iconBg="bg-orange-500"
        />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue vs Expense Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">รายได้ vs ค่าใช้จ่าย</CardTitle>
            <CardDescription>เปรียบเทียบรายได้และค่าใช้จ่ายรายเดือน</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `${v/1000}K`} />
                <Tooltip 
                  formatter={(value: number) => [`฿${value.toLocaleString()}`, '']}
                  labelStyle={{ color: '#374151' }}
                />
                <Legend />
                <Bar dataKey="revenue" name="รายได้" fill="#22c55e" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expense" name="ค่าใช้จ่าย" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* VAT Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ภาษีมูลค่าเพิ่ม</CardTitle>
            <CardDescription>ภาษีขายและภาษีซื้อรายเดือน</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={vatData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `${v/1000}K`} />
                <Tooltip 
                  formatter={(value: number) => [`฿${value.toLocaleString()}`, '']}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="vatOutput" 
                  name="ภาษีขาย" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="vatInput" 
                  name="ภาษีซื้อ" 
                  stroke="#f59e0b" 
                  strokeWidth={2}
                  dot={{ fill: '#f59e0b' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AR Aging */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ลูกหนี้ตามอายุหนี้</CardTitle>
            <CardDescription>จำแนกตามระยะเวลาครบกำหนด</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={arAgingData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {arAgingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `฿${value.toLocaleString()}`} />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {arAgingData.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-xs text-gray-600">{item.name}: ฿{item.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* AP Aging */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">เจ้าหนี้ตามอายุหนี้</CardTitle>
            <CardDescription>จำแนกตามระยะเวลาครบกำหนด</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={apAgingData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {apAgingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `฿${value.toLocaleString()}`} />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {apAgingData.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-xs text-gray-600">{item.name}: ฿{item.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">การดำเนินการด่วน</CardTitle>
          <CardDescription>รายการที่ต้องดำเนินการ</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                  <Receipt className="h-5 w-5 text-yellow-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-800">ใบกำกับภาษีร่าง</p>
                  <p className="text-sm text-gray-500">5 รายการรอออกใบกำกับภาษี</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                  <Users className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-800">ลูกหนี้เกินกำหนด</p>
                  <p className="text-sm text-gray-500">3 รายการเกิน 90 วัน</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-800">รอยื่นภาษี</p>
                  <p className="text-sm text-gray-500">PP30 ประจำเดือนนี้</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
