/**
 * Webhook Test API
 * Phase D: API Mastery - Webhooks
 * 
 * Endpoint:
 * - POST /api/admin/webhooks/[id]/test - Test webhook delivery
 */

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { testWebhook } from '@/lib/services/webhook-service';

// POST /api/admin/webhooks/[id]/test - Test webhook
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await auth();
    if (!session?.user || session.user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { id } = params;
    const result = await testWebhook(id);

    return NextResponse.json({
      success: result.success,
      data: {
        statusCode: result.statusCode,
        duration: result.duration,
        error: result.error,
      },
    });
  } catch (error) {
    console.error('Error testing webhook:', error);
    return NextResponse.json(
      { error: 'Failed to test webhook' },
      { status: 500 }
    );
  }
}
